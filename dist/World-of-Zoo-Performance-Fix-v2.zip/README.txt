WORLD OF ZOO PERFORMANCE FIX V2

Current reference build. Includes the menu and CPU-accessed mesh fixes.
The native ~30 FPS limit is preserved.

INSTALL
1. Close the game.
2. Open its installation folder containing WoZRetail.exe.
3. Back up any existing d3d9.dll outside the game folder.
4. Copy only the supplied d3d9.dll into the game folder.
5. Start through Steam. Check WoZIndexFix.log for the V2 title and both APPLIED lines.

REMOVE
Close the game, remove the added DLL, and restore your previous DLL if needed.

FRANCAIS
Fermer le jeu. Conserver la d3d9.dll actuelle en dehors du dossier du jeu,
puis copier uniquement la nouvelle d3d9.dll a cote de WoZRetail.exe.
Relancer par Steam. Pour revenir en arriere, fermer le jeu, retirer la
nouvelle DLL et restaurer la precedente.

The game EXE, saves, simulation and limiter are unchanged.
This ZIP contains the fix only; no game executable or assets are included.
Performance varies by graphics driver and scene. No universal gain is claimed.
Source, details and compatibility information are in the GitHub repository.
